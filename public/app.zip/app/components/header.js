import './header.css'

const Header = () => {
    return (
      <div className="header">
        <h1 >Hola soy un header</h1>
      </div>
    )
  }


export default Header;